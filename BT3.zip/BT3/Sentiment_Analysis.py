"""Hướng dẫn sử dụng : Chỉ cần chạy code và sẽ in ra kiểu đầu ra của Embedding, kết quả huấn luyện 
của dữ liệu đầu vào và kết quả chạy thử sau khi đã được huấn luyện .
Bài tập này được tham khảo bởi đường link sau : https://www.youtube.com/watch?v=JIafLwlGzBA&t=1185s&ab_channel=ProtonX"""
import numpy as np 
import os
def removeReturn(arr):
    for i in range (0,len(arr)):
        arr[i] = arr[i].rstrip(os.linesep)
    return arr

def StrToInt(so):
    for i in range(0,len(so)):
        so[i] = int(so[i])
    return so

# Đọc file train sents
with open('train_sents.txt', 'r', encoding='UTF-8') as fin1 :
    train_A=fin1.readlines()
fin1.close()
train_A=removeReturn(train_A)

# đọc file train sentiment 
with open('train_sentiments.txt', 'r') as fin2 :
    train_B=fin2.readlines()
fin2.close()
train_B=removeReturn(train_B)
train_B=StrToInt(train_B)


# đọc file test  sents
with open('test_sents.txt', 'r', encoding='utf-8') as fin3 :
    test_A=fin3.readlines()
fin3.close()
test_A=removeReturn(test_A)

# đọc file test  sentiment 
with open('test_sentiments.txt', 'r') as fin4 :
    test_B=fin4.readlines()
fin4.close()
test_B=removeReturn(test_B)
test_B=StrToInt(test_B)

# Chuyển kết quả sang dạng array 
train_B=np.array(train_B)
test_B=np.array(test_B)

# Huấn luyện dữ liệu đầu vào 
vocab_size=10000
embedding_zim=64
max_length=200

# Tách từ sử dụng Tokenizer 
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences

tokenizer = Tokenizer(num_words=vocab_size,oov_token='<OOV>')

tokenizer.fit_on_texts(train_A)
train_sequences=tokenizer.texts_to_sequences(train_A)
padded_train_sequence = pad_sequences(train_sequences,maxlen=max_length,truncating='post',padding='post')

tokenizer.fit_on_texts(test_A)
test_sequences=tokenizer.texts_to_sequences(test_A)
padded_test_sequence = pad_sequences(test_sequences,maxlen=max_length,truncating='post',padding='post')

from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding  
from tensorflow.keras.layers import Flatten
from tensorflow.keras.layers import Dense

# Tạo từ điển dữ liệu huấn luyện 
model = Sequential()
model.add(Embedding(vocab_size,embedding_zim,input_length=max_length))
model.add(Flatten())
model.add(Dense(10,activation='relu'))
model.add(Dense(1,activation='sigmoid'))
model.compile(loss='mean_squared_error',optimizer='adam',metrics=['acc'])
model.summary()
model.fit(padded_train_sequence,train_B,epochs=10,validation_data=(padded_test_sequence,test_B))

# chạy thử kết quả đã huấn luyện
fin5=open('input.txt', 'r', encoding='UTF-8')
test_example=fin5.readlines()
fin5.close()
test_example=removeReturn(test_example)

test_seq=tokenizer.texts_to_sequences(test_example)
ppadded_test_seq=pad_sequences(test_seq,maxlen=max_length,truncating='post',padding='post')
result=model.predict(ppadded_test_seq)
# Ghi kết quả vào file output
fin6=open('output.txt','w')
if result<0.45 :
    fin6.write('0')
    print(test_example,' : ','Tiêu cực .')
elif result >0.55 :
    fin6.write('2')
    print(test_example,' : ','Tích cực .')
else :
    fin6.write('1')
    print(test_example,' : ','Trung tính .')
fin6.close()
