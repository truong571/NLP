﻿import re 
file=open('FileVanBan.txt','r',encoding='utf-8')
text=file.read()
file.close()
email='[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+'
url = 'https?:\/\/[^\s]*'
sdt='[Z0-9]+[Z0-9]+[Z0-9]+[Z0-9]+[Z0-9]+[Z0-9]+[Z0-9]+[Z0-9]+[Z0-9]+[Z0-9]'
Email=re.findall(email,text)
URL=re.findall(url,text)
SDT=re.findall(sdt,text)
fin=open('dinhdang.txt','w') 
for x in Email: 
    start=str(text.find(x))
    length=str(len(x))
    list=(start,'\t',length,'\t',x,'\n')
    fin.writelines(list)
for x in URL: 
    start=str(text.find(x))
    length=str(len(x))
    list=(start,'\t',length,'\t',x,'\n')
    fin.writelines(list)
for x in SDT: 
    start=str(text.find(x))
    length=str(len(x))
    list=(start,'\t',length,'\t',x,'\n')
    fin.writelines(list)
fin.close()