#LSA

# Read file Text.txt
texts=[]
with open('Text.txt','r',encoding='utf-8') as file :
    texts=file.readlines()
file.close()

#Stop_words Vietnamese
def get_stopwords():
    with open('StopWord.txt', 'r', encoding="utf-8") as fin:
        stopwords = fin.readlines()
        stop_set = set(m.strip() for m in stopwords)
    fin.close()
    return list(frozenset(stop_set))

stopwords=list()
stopwords = get_stopwords()

# Importing the Tf-idf vectorizer from sklearn
from sklearn.feature_extraction.text import TfidfVectorizer

# Defining the vectorizer
vectorizer = TfidfVectorizer(stop_words=stopwords, max_features= 100000,  max_df = 0.5, smooth_idf=True)

# Transforming the tokens into the matrix form through .fit_transform()
matrix= vectorizer.fit_transform(texts)

# SVD represent documents and terms in vectors
from sklearn.decomposition import TruncatedSVD
SVD_model = TruncatedSVD(n_components=28, algorithm='randomized', n_iter=100, random_state=122)
SVD_model.fit(matrix)

# Getting the terms 
terms = vectorizer.get_feature_names()

# Iterating through each topic
with open("output.txt", 'a', encoding="utf-8") as f:
    for i, comp in enumerate(SVD_model.components_):
        terms_comp = zip(terms, comp)
        # sorting the 10 most important terms
        sorted_terms = sorted(terms_comp, key= lambda x:x[1], reverse=True)[:10]
        f.write("Đoạn "+str(i)+": \n")
        # printing the terms of a topic
        for t in sorted_terms:
            f.write(t[0]+' ')
        f.write('\n')
    f.close()